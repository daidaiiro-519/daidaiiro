# Product Vision & Design Principles

## Vision

**PdMの思考を民主化し、プロダクトマネジメントを加速する。**

PdM Agentの目的は人間の代わりに正解を出すことではない。まだ言語化できていない問題・目的を仮説として捉え、比較可能な探索候補と成果物へ変換し、根拠とともに示し、より良い意思決定を可能にすること。

製品名称: `AI Product Management Workspace` / Agent: `PdM Agent` / UI体験: `Purpose Discovery Journey` / Knowledge: `Semantic Knowledge Engine`。

## ユーザー起点

- 初心者は思い付きや違和感を入力するだけで始められる。PdMの正式な課題定義は要求しない。
- 熟練PdMは履歴、対抗仮説、判断根拠、探索予算と収束判定を短い操作で確認できる。
- 利用者はAIへの逐一指示・専門的フレームワークの選定を押し付けられない。重要な判断だけ承認する。

## UX principles

1. **AI Initiative / Human Approval** — 提案はAI、探索と目的の意思決定は人間。候補選択だけで承認は発生しない。
2. **Preview Before Approval** — 複数の重要な探索候補を承認前に比較し、選択した候補の具体的なプレビューと承認の範囲を確認。
3. **Concrete ↔ Abstract, Not Abstract At All Costs** — 具体化は目的の問い直しを起こし、再抽象化は新たな具体化を導く。高い抽象度それ自体はゴールではない。
4. **Non-destructive & Revisitable** — 未選択候補、過去の仮説、成果物、探索結果、承認を残す。戻ったとき過去を消さない。
5. **Convergence by Reason** — 価値・適切な抽象度・安定性・検証可能性・追加探索価値の5軸で区切りを判断。
6. **Evidence & Uncertainty** — 観測・資料・人間の主張・AI推論を区別。妥当性の根拠がない確信度を表示しない。
7. **Ubiquitous Language by Design** — ドメイン用語は明確に定義し、初見ユーザーは会話や説明の中で自然に理解できる。
8. **Progressive Disclosure** — 入口は軽く、比較と説明は十分に、知識の出典やAdvisorの方法論は必要時に深掘り。

## Goal vs non-goal

目標: 不確実性を減らし、検証可能で実務判断に使える目的仮説を、人間が暫定承認できる状態にする。

非目標: AIが正解を断定する、最初の解決策を目的として固定する、UIを大量生成する、発散を繰り返す、承認を検証済みとみなす。
