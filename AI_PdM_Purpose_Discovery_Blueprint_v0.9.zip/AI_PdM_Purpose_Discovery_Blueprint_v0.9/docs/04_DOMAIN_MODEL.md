# Purpose Discovery — Domain Model v0.8

## Bounded Contexts

- **Purpose Discovery**: 目的仮説、探索候補、探索ステップ、成果物、探索結果、承認、目的の収束判定。
- **Product Knowledge**: 参照された業務資料、決定、根拠の意味モデル。Discovery側はEvidenceReferenceで参照。
- **Advisor / Method Knowledge**: DDD、META、UX、Data Science等の方法論。各手法を適用すること自体がユーザーへの意思決定にならない。
- **Value Validation**: 調査・実験・検証計画。暫定承認された目的仮説、未検証事項を受け取る。

## モデル（概念）

```mermaid
flowchart TD
  J[DiscoveryJourney] --> PH[PurposeHypothesisVersion]
  J --> O[ExplorationOption]
  J --> S[ExplorationStep]
  O -- human approval --> AP[ApprovalRecord]
  AP --> S
  S --> A[ExplorationArtifact]
  S --> F[ExplorationFinding]
  F --> ER[EvidenceReference]
  F --> HR[HypothesisRevisionProposal]
  HR --> PH
  J --> C[PurposeConvergenceAssessment]
  C --> P[ProvisionalPurposeApproval]
  P --> V[ValidationBrief]
```

## 重要な不変条件

1. 未承認の`ExplorationOption`から実施済み`ExplorationStep`を作成しない。UIの単なる選択は承認ではない。
2. `ApprovalRecord`には対象のIDとバージョン、承認の意味、操作者、時刻、冪等キーを保存。
3. `PurposeHypothesisVersion`を暗黙に更新しない。改訂案・人間の承認・更新前後の版を記録。
4. `ExplorationArtifact`を生成したことを`ExplorationFinding`の証拠とみなさない。出典と推論の区別が必要。
5. 過去の探索ステップや承認の既存内容を書き換えない。修正は新しいイベントで表現。
6. 過去ステップの未選択候補は後から再評価できる。再開時は別IDのステップを派生。
7. `PurposeConvergenceAssessment`は暫定承認の決定権を持たない。
8. 暫定承認により価値が実証されたことにはしない。

## 状態遷移の最小集合

- Option: `PROPOSED → SELECTED_FOR_PREVIEW → APPROVED | REJECTED | DEFERRED`。`SELECTED_FOR_PREVIEW`に意思決定の効力はない。
- Step: `PLANNED → RUNNING → AWAITING_FEEDBACK → RECORDED`、途中の失敗は`FAILED`で保存。
- Hypothesis: `PROPOSED → ACTIVE → REVISED | SUPERSEDED → PROVISIONALLY_APPROVED`。実際には版管理を推奨。
- Journey: `DRAFT → EXPLORING → CONVERGENCE_REVIEW → PROVISIONALLY_CONCLUDED → VALIDATING`。重要な情報で探索を再開可能。

## Aggregate境界（初期仮説）

`DiscoveryJourney`を巨大Aggregateにしない。承認をトランザクション境界にする場合は`ApprovalRecord`と該当Option/Stepとの整合性をユースケースで保証し、永続層のトランザクションと冪等性を用いる。`ExplorationArtifact`の重いデータは参照と版で分ける。`EvidenceReference`はKnowledge contextのデータを複製せず識別子でつなぐ。

## 実装とUIの名称対応

- 「探索ステップ03」= `ExplorationStep.id` を表示用序数に変換したもの。固定の画面番号ではない。
- 「探索候補」= `ExplorationOption`。
- 「成果物」= `ExplorationArtifact`（種類の判別は画面案・フロー・調査計画など）。
- 「探索結果」= `ExplorationFinding`（evidence/interpretation/uncertainty）。
