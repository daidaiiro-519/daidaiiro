# Design System v0.1 — 統合と診断UI

既存デザインシステムを`design-system/`に展開し、カラーテーマ5種類（Botanical / Deep Ocean / Insight / Warm Editorial / Graphite）、Token、Themeable UI、比較スクリーンショットを保持する。

## 新たなSemantic Diagnostics表示方針

- デザインの色は状態そのものを表現する契約ではない。ブランドThemeと契約診断は意味上別物。
- `verified`、`violated`、`unverified`、`unsupported`を文字・アイコン・説明・必要に応じた色で区別する。色だけで区別しない。
- 承認前プレビューでは「何を検証できたか／できないか」「何を承認するか」を分離。
- 初回入力画面を維持。エンドユーザーにSchemaの入力や低レベル形式を強制しない。
- 専門家向け詳細パネルは段階的開示。DDD/METAの用語とUI用語はコンテキスト内で整合させる。

参考: `design-system/DESIGN_SYSTEM.md` / `design-system/COLOR_OPTIONS.md` / `design-system/preview/purpose-discovery-v0.8-themeable.html`。
