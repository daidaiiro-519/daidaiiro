# 機械的検証とセマンティック検証の契約

## 原則

1. **Expression-first**: 守るべき意味契約は、表現可能性を契約モデルの上限に据えて宣言する。JSON SchemaやSHACL等の制約に従って意味を削らない。
2. **Declare → Interpret → Verify**: 契約の宣言と解釈実装を分離する。Interpreterは必要なCapabilityを公開する。
3. **Fail-closed for required semantics**: 必須制約の未対応・未検証を成功扱いしない。
4. **Loss awareness**: 射影された外部形式の情報欠落を診断する。原本JSONを保持。
5. **Traceability**: どのContractのどの版を、どのInterpreterのどのCapabilitiesで、どの根拠に基づき、どう評価したか記録する。
6. **Authority separation**: Structural validity、Semantic judgment、Human approval、Real-world value validationを一つのBooleanに潰さない。

## 推奨する論理的な検証フロー

`AI generates candidate JSON` → `Abstract conformance` → `Concrete shape/relations` → `Vocabulary resolution` → `Capability matching` → `Structural/Formal/Semantic interpreters` → `Structured diagnostics` → `AI repairs violations if permitted` → `Human reviews previews and approves scope`。

### 代表的な診断例

| Condition | Meaning | Product behavior |
|---|---|---|
| `verified` | 該当制約の条件を評価し適合と判定 | 根拠・対象版を保持して提示可能 |
| `violated` | 制約違反を検出 | 修正/対立仮説/手動判断へ |
| `unverified` | 契約はあるが根拠・状況が不十分で未評価 | 不明として明示。必須ならGateを閉じる |
| `unsupported` | Capabilityがなく解釈できない | 対応Interpreterを探す/実装する。必須ならGateを閉じる |

この4分類は統合設計の推奨案。原典の`unsupported` / `unverified`を成功にしない原則を継承する。確定Protocolの列挙値とは扱わない。

## Human Approvalとの境界

探索候補のプレビューを表示するための最低条件と、探索ステップ開始に必要な条件は同一とは限らない。表示は`unverified`を含めて可能だが、必須契約未検証のステップを適合済みとして承認実行へ移してはならない。危険や未検証状態を正しく表示できるUIが必要。

### 目的の収束判定の例

- `pdm.purpose.value-clarity`: 対象ユーザー・問題・提供価値の明確さ。
- `pdm.purpose.abstraction-fitness`: 解決手段に過度に固定されず、判断可能な抽象度。
- `pdm.purpose.stability`: 異なる成果物/対抗仮説を通して中心目的が維持されるか。
- `pdm.purpose.testability`: 次の外部検証を設計できるか。
- `pdm.purpose.marginal-learning-value`: 継続探索による追加学習価値。

評価項目は**すべてSchemaに宣言**し、結果も型付きで持つ。一方でAI評価の`verified`は世界の客観的真実を証明しない。証拠に基づく解釈結果の範囲を明示する。

## Interpreterの信頼性（PoCで検討）

AI Semantic Interpreterの出力の決定性は当然の保証ではないため、入力ハッシュ・モデルと設定・評価基準・使用Evidence・評価結果と説明を記録し、再評価可能性と人手判断の一致率を検証する。Schema定義はこの不確実性を表現できなければならない。
