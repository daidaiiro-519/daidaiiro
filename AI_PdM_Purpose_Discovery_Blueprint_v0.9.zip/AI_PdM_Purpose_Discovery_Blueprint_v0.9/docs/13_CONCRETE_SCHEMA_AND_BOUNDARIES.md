# Bounded Context・Vocabulary・Concrete Schemaの配置

## 境界の設計

### 共通契約層：Semantic Contract Core

`Contract` / `Vocabulary` / `Relation` / `Constraint` / `Interpretation` / `Instance` などの基本概念を仮置きする。ただしどれをAbstract Schemaの正式プリミティブとするかは未決。用途固有の`PurposeHypothesis`や`Build`はAbstractの必須語彙にはしない。

**不変な合意:** 何を守るかをSchemaで表現し、その定義にInterpreterやAdapterを接続する。対応不明な意味を勝手に検証成功にしない。Abstractに対するConcreteの拡張は適合条件を壊してはいけない。

### Purpose Discovery Concrete Schema

| 用語（UI/共通語彙） | Concept ID案 | 契約例 |
|---|---|---|
| 目的仮説 | `pdm.PurposeHypothesis` | 版・対象・期待価値・根拠と未確定性を保持 |
| 探索候補 | `pdm.ExplorationOption` | 対象仮説と探索で判明させたいことを参照 |
| 探索プレビュー | `pdm.ExplorationPreview` | 生成/想定成果物、理由、未検証事項、承認スコープを提示 |
| 探索ステップ | `pdm.ExplorationStep` | **承認済み**候補とApprovalRecordに由来する |
| 成果物 | `pdm.ExplorationArtifact` | 種別・生成元・版・参照・契約診断を保持 |
| 探索結果 | `pdm.ExplorationFinding` | 観測・推論・反証・未解決を区分、根拠を参照 |
| 承認記録 | `pdm.ApprovalRecord` | 対象ID/版/スコープ/人間/時刻/冪等キーを保持 |
| 目的の収束判定 | `pdm.PurposeConvergenceAssessment` | 判断基準・根拠・未検証事項・推奨・Human Gate |
| 価値検証 | `pdm.ValueValidation` | 目的暫定承認後の外部検証; 契約適合とは別 |

### 兄弟用途のConcrete Schema

- Development Schema: Artifact / Dependency / Build / Verification等。Schema駆動開発Platformは**このSchemaの利用者**でありSchemaそのものではない。
- UI / Workflow Schema: Component / Action / State / Transition / Guard等。PdM画面のUI仕様も契約化できるが、すべての描画実装を宣言へ置き換えることが目的ではない。

## 形式に乗らない意味を捨てない

- JSON Schemaでは定義不能な`abstraction-fitness`（目的の抽象度の適切さ）の意味契約も、Concrete Schemaから削除しない。
- 独自Vocabularyに宣言し、Semantic Interpreterが根拠と限界を報告する。
- Interpreterが未対応で、かつその項目が必須なら**承認可能な検証済み状態に移してはならない**（fail-closed）。どのHuman Gateを閉じるかはPurpose Discoveryのポリシーで規定する。
- 「人間による探索承認」と「契約が適合したこと」と「目的が価値あること」は別の判定軸。

## Schema変更フロー（提案）

契約変更案 → DDDで意味・境界の整合確認 → METAで目的/手段/抽象度の偏り確認 → 互換性・既存Instance検査 → 必要権限を持つ人間が承認 → バージョン更新と再検証。
