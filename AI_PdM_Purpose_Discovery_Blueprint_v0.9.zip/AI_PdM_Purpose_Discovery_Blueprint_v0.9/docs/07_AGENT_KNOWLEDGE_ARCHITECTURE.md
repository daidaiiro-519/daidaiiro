# Agent / Knowledge Architecture & Responsibilities

## 基本設計

ローカルのバックエンドプロセスがClaude Code、Codex CLI等をPort/Adapterで起動。GUIはローカルブラウザで実行。AIがKnowledgeを利用して目的仮説、探索候補、成果物、根拠、収束判定を構成する。初期PoCはNode.js/TypeScriptのローカルサーバ、Vue3または同等のUI、SQLite/ファイル、SSEイベントなどを候補とする（未決）。

## 思考の分担（論理的責務。必ずしも別々のプロセスではない）

- **Discovery Orchestrator**: 現在地と、次に最も学習価値のある活動を判断。
- **Purpose Inference Advisor**: 曖昧な発言から目的仮説と対抗仮説を生成し、根拠・前提を分離。
- **DDD Advisor**: 語彙の整合性、境界づけられたコンテキスト、概念の重複をレビュー。
- **META Advisor**: 目的・手段の混同、抽象度の適切さ、具体と抽象の往復をレビュー。
- **Artifact Generator**: 画面案、業務フロー、分析結果、検証計画など適切な成果物を生成。
- **Findings Interpreter**: ユーザーの違和感と観測結果を区別して仮説の改訂案を構築。
- **Convergence Evaluator**: 5観点を根拠付きで評価。収束したと断定しない。
- **Approval Coordinator**: 対象・版・影響範囲を明示し、人間の明示承認の記録と重複排除を管理。

## Semantic Knowledge Engine

生資料（文書、Markdown、Issue、会議記録など）を保持し、意味づけされたProduct Knowledgeへ変換する。単純なベクトル検索だけを設計中心にはしない。参照リンク・出典・版・信頼度区分・reading protocolを保持。正規化時に失われた情報を見直せるようRaw Source参照を残す。

`Purpose Hypothesis`、`Evidence`、`Constraint`、`Decision`、`Assumption`、`Requirement`等の意味モデルを境界内で明確化。Advisor Knowledgeは方法論と評価の観点を提供するが、業務上の観測事実や人間の承認を上書きしない。

## Ports

- AgentExecutionPort：起動・キャンセル・ストリーム・失敗を抽象化。
- KnowledgePort：SourceReference、semantic record、context retrieval。
- ArtifactPort：プレビュー生成・成果物バージョン・取得。
- ApprovalPort：人間の承認・監査・冪等な保存。
- JourneyRepositoryPort：探索グラフ、仮説版、探索結果。

## セキュリティ/プライバシー

CLIを起動する際は許可リスト、パスの正規化、コマンド引数のエスケープと権限の分離が必要。ローカルサーバから外部のモデルへ送信し得る範囲は明示する。初期デモの資料アップロード表示は内容を読み込まない。
