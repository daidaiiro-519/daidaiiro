# Implementation Handoff — Claude Code / Codex

## 最初に再現するもの

`prototype/index.html`の初回入力〜価値検証への通し体験を実アプリの縦切りとして実装。旧v0.7の探索ステップ03起点の画面を製品の初期状態にしない。

## 推奨スライス

1. `Journey`を作成し、自由入力と任意のSourcesを安全に保存する。
2. AIに初期仮説・複数の探索候補（例2〜3件）を返させ、根拠と未検証事項を構造化する。
3. 候補プレビューを生成・比較。選択と承認を別イベントに分離する。
4. 承認をトランザクション＋冪等キーで保存し`ExplorationStep`を生成。
5. 成果物を表示し、人間の違和感を取得して探索結果として保存、目的仮説更新案を提示。
6. 未選択の候補へ戻り、派生ステップを追加（過去を不変にする）。
7. 根拠付きの目的の収束判定を提示し、暫定承認から価値検証用Briefを生成。

## API/イベントの一例（設計案）

```
POST /journeys                        // input and optional sources
GET  /journeys/:id                    // current state
POST /journeys/:id/infer              // AI-generated hypotheses/options
GET  /journeys/:id/options            // candidates and previews
POST /journeys/:id/options/:optionId/select    // non-binding UI selection (optional)
POST /journeys/:id/options/:optionId/approve   // human approval; idempotency
POST /journeys/:id/steps/:stepId/feedback
POST /journeys/:id/hypothesis-revisions/:id/approve
GET  /journeys/:id/history
POST /journeys/:id/convergence-assessments
POST /journeys/:id/purpose-approvals
GET  /journeys/:id/validation-brief
```

注意: ルート設計は最終API仕様ではない。重要なのは承認境界、型、安全性、非破壊履歴。

## フロントの状態区分

`zeroState`、`inferenceReady`、`optionsReady`、`previewing`、`awaitingApproval`、`stepRunning`、`awaitingFeedback`、`findingsReady`、`convergenceReview`、`purposeProvisionallyApproved`、`validationHandoff`。

画面は状態だけから固定的に導くのではなく、履歴・選択候補・現在の目的仮説・観測された未検証事項から構成する。

## 技術的留意事項

- 生資料をAIへ注入する際は内容を信頼しない。プロンプトインジェクションを防ぐ境界を置く。
- 応答はJSON Schema等で検証、異常時はUIに構造的エラーを示す。
- ストリーミング中もユーザーはキャンセル可能。承認処理はユーザーアクションでのみ実行。
- ローカルキャッシュからの再開とクラウド同期は将来の拡張。同期失敗時に履歴が壊れないこと。
- 使用するAdvisorは「ローカル/外部の参照知識に基づく方針」であり、資料未読なのに参照済みとは主張しない。
