# v0.9 追加決定ログ

| ID | 区分 | 決定内容 | 状態 |
|---|---|---|---|
| SC-01 | 原則 | 遵守・検証すべき意味契約をSchema外に暗黙化しない | 方針合意 |
| SC-02 | 境界 | Abstract Schemaは共通意味契約。用途依存VocabularyはConcrete側 | 方針合意 |
| SC-03 | 境界 | PdM ConcreteとDevelopment Concreteは兄弟。開発PlatformはSchemaの利用者 | 方針合意 |
| SC-04 | Engine | 意味宣言と解釈を分離。InterpreterはCapabilityを宣言 | 方針合意 |
| SC-05 | 検証 | 必須のSemantic未対応/未検証をverifiedにしない | 方針合意 |
| SC-06 | 技術 | 標準ツールはAdapter。独自の意味契約表現を標準に合わせて削らない | 方針合意 |
| SC-07 | UX | 最初の自由入力、複数探索候補のプレビュー、Human Approval、復帰、収束、価値検証を保持 | 既存合意を継承 |
| SC-08 | PoC | PdM ConcreteとDevelopment Concreteを同一Abstractに接続する縦断検証 | 提案 |
| SC-09 | 未決 | Abstractの最小プリミティブ、具体的なJSON形式、AI評価再現性 | 未決 |

**廃止する過去の示唆:** 「Schemaには表現できない意味があるため、PdMの推論はSchemaの外でよい」という意図の一般化は撤回。**Schema契約に意味を宣言する**。ただしInterpreterの検証能力・証拠と実世界の真実は別途区別する。
