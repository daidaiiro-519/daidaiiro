# Semantic Contract Core × Purpose Discovery — 統合方針 v0.9

> 2026-10-17 / Status: 共同構想の設計基準（実装済みとの主張ではない）
> 優先順位: 本書およびdocs/13〜17は、旧v0.8のアーキテクチャ記述と矛盾する場合に統合方針として優先する。目的探索UX・Human Approvalの原則は旧版から維持する。

## 合意した設計修正

過去の「すべてをSchemaで表現しようとしない」という提案は撤回する。問題はSchemaの外へ意味契約を逃がすことではなく、遵守・検証すべき契約の意味を**型付きの契約として宣言できない**ことにある。

1. **Abstract Schema（共通抽象契約）** — ドメインに非依存な意味契約の識別・構造・関係・制約・拡張・検証結果に関する共通の規則。用途固有語彙を必須要素にしない。Abstract Schemaを破壊する拡張は禁止。
2. **Concrete Schema（用途別の契約の具体化）** — Abstract Schemaの規則に準拠し、Purpose Discovery固有のVocabularyと型、関係、制約、判断ポリシーを宣言する。開発用Concrete SchemaやUI/Workflow用Concrete Schemaも同じレベルの独立した具体化。
3. **Vocabulary** — 概念・意味・関係・述語を識別し、Concrete Schemaの契約の語彙を供給する。DDDのユビキタス言語との関係を管理。
4. **Interpreter / Semantic Contract Engine** — Schemaを解釈して構造的・形式的・意味的な契約適合を評価するソフトウェア。宣言と実装を分離し、Capabilityを照合する。Rust実装は候補だが公開契約は言語非依存。
5. **Adapter / Projection** — JSON Schema / JSON-LD / RDF / SHACL / OpenAPIなどを部分的に使用可能。いずれも抽象意味表現の上限を規定しない。Projectionの損失と未対応領域を明示する。

## PdM側への接続

- PdM AgentはPurpose Discovery Concrete Schemaに従って目的仮説・探索候補・プレビュー・探索ステップ・成果物・探索結果・承認記録・収束判定を生成・更新する。
- Semantic Knowledge EngineはRaw Sourceから意味モデルを抽出・保存・参照し、**Semantic Contract Coreはそれらが従う契約を宣言・解釈・検証する**。Core自体をKnowledge Storeとして規定しない。
- DDD/META/UX/DSのAdvisor Knowledgeは推論に用いる方法知。Vocabulary/Contractを更新する場合はバージョンと人間の合意が必要。
- UIは複数の探索候補をプレビューし、契約の診断結果・根拠を必要な粒度で開示する。Schemaへの適合だけで人間の承認を代替しない。
- Human Approvalは目的探索のドメイン上の正式な判断イベント。AIが`verified`を返しても目的や価値の正しさを保証しない。

## 非混同

| 契約の層・機構 | 正体 | PdM固有か |
|---|---|---|
| Abstract Schema | 共通抽象契約の規則 | いいえ |
| Purpose Discovery Vocabulary | 目的探索の概念・意味の辞書 | はい |
| Purpose Discovery Concrete Schema | 目的探索の意味と制約の宣言 | はい |
| Semantic Contract Engine | 宣言の解釈・検証を担う実装 | いいえ |
| Semantic Knowledge Engine | 知識の正規化・参照・更新を行うアプリケーション側機能 | PdM向けに構成される |
| Schema駆動開発 Concrete Schema | 開発領域の意味・制約の宣言 | いいえ（別用途） |
| Schema駆動開発 Platform | 開発用Concrete Schemaを消費する実行アプリ | いいえ（別用途） |

## 参照と未決事項

原典: `references/semantic-contract-core-v0.3/docs/10_abstract-concrete-schema-boundaries.md`、`11_semantic-layered-model.md`、`14_standards-as-optional-adapters.md`、`17_decision-ledger-v0.3.md`。

未決: Abstractプリミティブの最小集合、メタ形式と継承/合成の厳密な意味、Vocabulary競合・互換性、永続形式、Interpreter Protocol詳細、信頼できるAI評価の再現性指標。原典もv0.3段階のブレストであり、完成したEngineを意味しない。
