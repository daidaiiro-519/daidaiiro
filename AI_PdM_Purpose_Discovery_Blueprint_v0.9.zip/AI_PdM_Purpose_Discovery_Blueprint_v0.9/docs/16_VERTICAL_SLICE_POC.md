# PoC — 共通Abstract / PdM Concrete / Development Concrete

## 狙い

単純なモック制作ではなく、異なる2用途のConcrete Schemaが同一Abstract Schemaに準拠し、PdMの探索フローで構造と意味の検証が動くか確かめる。

## P0: 契約表現のスパイク（疑似実装でもよい）

- Abstract側に最低限の契約ID、Vocabulary参照、制約、必須度、Interpreter Capability、診断結果を表すメタ規則の**候補**を定義。
- PdM用途の`ExplorationOption` / `ApprovalRecord` / `PurposeConvergenceAssessment`について必須制約を宣言。
- Development用途の`Artifact` / `Dependency` / `Verification`を同形式で宣言。PdM語彙をAbstractの基本型に混ぜていないことを確認。
- Schema原本JSONを保存、Adapter射影はloss reportを持つ。

## P1: Human ApprovalまでのVertical Slice

曖昧な入力 → 複数目的仮説と探索候補（2〜3件） → Concrete Schema適合とInterpreter評価 → 承認前にDiagnostics確認 → 人間が候補承認 → 探索ステップ新規作成 → Findings更新 → 過去候補へ戻る。

### Acceptance

- AC01: 未承認Optionから開始済みStepが生まれない。
- AC02: `required` Semantic Predicateが`unsupported`のとき検証成功を出さない。
- AC03: 対象ID/版/根拠/Interpreter versionを検証結果に保持。
- AC04: JSON Schema Adapterが扱えない意味契約を、射影時に黙って消さない。
- AC05: PreviewとApprovedは別状態。選択しただけではApprovalEventを作らない。
- AC06: 過去のOptionへ戻っても旧Approval/Eventは破壊されない。
- AC07: 「目的の収束判定」はAI評価の根拠と人間の暫定承認が分離される。
- AC08: 異なるConcrete Schemaを利用してもAbstractの共通契約に変更は不要。
- AC09: 初回入力は自然言語で開始できる。Schema入力を人間に強制しない。
- AC10: 結果表示の`verified`は実世界の価値検証の成功と区別される。

## 未実装・PoC後の論点

Vocabularyの長期互換性、Predicate意味論の完全な形式化、外部Interpreterの実行権限、AI判定の再現性、Deployment/Sync、収束判定の妥当性に対するユーザーテスト。
