# v0.9 Visual Assets

- `12_semantic_contract_integrated_one_page.png`: Purpose DiscoveryとSemantic Contract Coreの統合一枚絵（ピクセル版）。
- `12_semantic_contract_integrated_one_page.html`: 同じメイン一枚絵の編集可能なHTML（レイアウトの正本）。
- `12_semantic_contract_integrated_one_page.svg`: 編集可能なネイティブSVG（簡略化した構造図）。
- `13_semantic_diagnostics_wireframe.png` / `.html`: 承認前探索プレビューに診断結果を表示する設計案。サンプル結果であり未接続。
- `01_start.png`〜`11_storyboard.png`: v0.8から保存した、初回入力〜収束・価値検証までのUXモックと資料。
- `design-system/`: デザインシステムv0.1の5テーマ・トークン・比較HTMLを同梱。

**注意**: 図中のVocabulary/Contract要素やInterpreterは設計候補。v0.3 Core自体もブレスト段階であり、実装済みではありません。
