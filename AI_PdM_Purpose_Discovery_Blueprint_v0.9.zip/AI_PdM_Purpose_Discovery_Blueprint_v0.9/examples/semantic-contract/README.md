# Example status

このディレクトリのJSONは、合意した責務配置の**概念例**であり、Semantic Contract Core v0.3の正式なメタスキーマ・Interpreter Protocol・完成実装ではない。正式Schema確定後に差し替える。
