# Examples

`contract.example.json` は独自Semantic Contractの**仮の表現**です。規格・正式メタモデルではありません。`sensor.schema.json` は標準JSON Schema形式で書いたデータ契約です。`ui.example.json` は独自UI Contractの概念例であり、現在のどのRendererでもそのまま動く保証はありません。

## v0.3追加

- `semantic/vocabulary.duration.example.json`: Vocabulary試案
- `semantic/concrete.sensor.example.json`: Concrete Contract試案
- `semantic/instance.sensor.*.json`: 適合／不適合のデータ例
- `protocol/interpreter-{request,response}.example.json`: 言語非依存Interpreter Protocol試案
- `protocol/projection-report.example.json`: 外部標準へ部分射影した場合の診断例

これらは動作するプロダクト仕様ではなく、ブレストのためのサンプル。
