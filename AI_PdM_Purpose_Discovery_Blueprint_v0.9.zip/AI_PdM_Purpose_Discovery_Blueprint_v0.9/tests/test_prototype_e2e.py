#!/usr/bin/env python3
"""Static prototype smoke test. Requires playwright and a Chromium binary.

Runs via page.set_content(), so no network, file:// access, or web server is required.
This validates the UX demo only. It does NOT validate real LLM inference or persistence.
"""
from pathlib import Path
import os
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'prototype/index.html').read_text(encoding='utf-8')
with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True,executable_path=os.environ.get('CHROMIUM_BINARY','/usr/bin/chromium'),args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1440,'height':900})
    errors=[]
    page.on('pageerror',lambda exc:errors.append(str(exc)))
    page.set_content(HTML,wait_until='load')
    assert page.locator('h1').first.inner_text()=='まだ、言葉になっていないことから。'
    page.locator('#idea').fill('現場の点検を楽にしたい。目的はまだ曖昧。')
    page.locator('[data-action="begin"]').click()
    assert 'AIの解釈' in page.locator('h1').first.inner_text()
    page.locator('[data-go="options"]').last.click()
    assert page.locator('.option').count()==3
    assert page.get_by_text('AI推奨例：B').count()==1
    page.locator('[data-action="select"][data-id="B"]').click()
    page.locator('[data-go="preview"]').click()
    assert '承認の範囲' in page.locator('body').inner_text()
    page.locator('[data-action="approve-modal"]').click()
    assert page.get_by_role('dialog').count()==1
    page.locator('[data-action="confirm-exploration"]').click()
    assert '成果物' in page.locator('body').inner_text()
    page.locator('#feedback').fill('業務の中断こそ問題なのではないか')
    page.locator('[data-action="record-findings"]').click()
    assert '探索結果' in page.locator('body').inner_text()
    page.locator('[data-action="approve-hypothesis"]').click()
    assert '記録済み' in page.locator('body').inner_text()
    page.locator('[data-go="options"]').last.click()
    page.locator('[data-action="select"][data-id="C"]').click()
    page.locator('[data-go="preview"]').click()
    page.locator('[data-action="approve-modal"]').click()
    page.locator('[data-action="confirm-exploration"]').click()
    page.locator('[data-action="record-findings"]').click()
    page.locator('[data-go="history"]').last.click() if page.locator('[data-go="history"]').count()>0 else page.locator('[data-go="history"]').click()
    assert page.get_by_text('探索ステップ 2',exact=False).count()>=1
    page.locator('[data-go="convergence"]').first.click()
    assert '探索継続を推奨' in page.locator('body').inner_text()
    page.locator('[data-action="convergence-demo"]').click()
    page.locator('[data-action="purpose-modal"]').click()
    assert page.get_by_role('dialog').count()==1
    page.locator('[data-action="confirm-purpose"]').click()
    assert '価値検証' in page.locator('h1').first.inner_text()
    assert not errors,errors
    print('PASS: first input → hypotheses → 3 candidates → preview → approval → artifact → findings → revisit → convergence → value validation')
    browser.close()
