# AI Product Management Workspace — Purpose Discovery Blueprint v0.9

**更新日: 2026-10-17** ｜ Semantic Contract Core統合・一枚絵更新版

> v0.8のエンドツーエンドUX、UIワイヤーフレーム/スクリーンショット/HTMLデモ、既存PoC仕様は維持し、新たに**Semantic Contract Core v0.3との統合境界**を追加しました。

## 最初に見るもの

1. **新しい全体構想の一枚絵**: `visuals/12_semantic_contract_integrated_one_page.png`（編集可能HTML/SVGも同梱）
2. **最新の統合仕様**: `docs/12_SEMANTIC_CONTRACT_CORE_INTEGRATION.md` ～ `docs/18_INTEGRATION_DECISION_LEDGER.md`
3. **初回入力からの操作デモ**: `prototype/index.html`（v0.8の静的デモを保持）
4. **初回入力・候補比較・分岐・収束のスクリーンショット**: `visuals/01_start.png` ～ `visuals/11_storyboard.png`
5. **デザインシステム**: `design-system/DESIGN_SYSTEM.md`、`design-system/preview/color-lab.html`（5テーマ）
6. **Semantic Contract Core原典v0.3**: `references/semantic-contract-core-v0.3/README.md`。正式仕様が完成済みであることを意味しません。

## v0.9の重要事項

- **Abstract Schema**は用途非依存の共通意味契約。**Concrete Schema**はその契約を守った用途別の拡張。
- **Purpose Discovery Concrete Schema**と**Schema駆動開発用Concrete Schema**は兄弟用途。Schema駆動開発Platformは開発用Schemaの利用者。
- 守るべき意味契約は**Schemaに宣言**する。Structural / Formal / AI Semantic Interpreterの実装と宣言は分離。
- 未対応・未検証の必須制約は成功として扱わない。外部標準に射影できない表現を黙って捨てない。
- UXは**曖昧な初回入力→目的仮説→複数の探索候補→承認前の探索プレビュー→探索ステップ→成果物/探索結果→復帰→目的の収束判定→人間の暫定承認→価値検証**を維持。
- **構造的適合 / 意味的評価 / 人間の承認 / 現実の価値検証**は別々の概念。

## ソース・既存資産の状態

- `docs/00_...` ～ `docs/11_...` はv0.8から引継ぎ。
- `docs/12_...` ～ `docs/18_...` は本統合の追加仕様。
- `prototype/index.html`は静的UX検証用で、Semantic Contract Engineを動作させません。
- `examples/semantic-contract/*.concept.json`は**概念例**であり、Abstract Schemaの正式な構文ではありません。
- `references/semantic-contract-core-v0.3/` は受領した原資料の複製。必要に応じて原文と照合してください。
- `design-system/` は直近のデザインシステムv0.1を展開したものです。

## v0.8の説明（履歴）

# AI Product Management Workspace — Purpose Discovery Blueprint v0.8

**2026-10-12 / End-to-End UX Rebuild / 設計・検証用スナップショット**

## 今回の改訂で解決すること

v0.7のUIモックは、いきなり探索ステップ03から始まっており、初めてのユーザーがどこで入力するか、AIの初期解釈がどのように探索候補になるか、その後どう判断・復帰・収束するかを一つのUXとして表現できていませんでした。

**v0.8では「曖昧な初回入力」を起点とした一連の体験に再設計しました。**

入力 → AIの初期解釈 → 複数の探索候補を比較 → 詳細プレビュー → 人間の承認 → 探索ステップ → 成果物を評価・違和感入力 → 探索結果と目的仮説の更新 → 他候補へ復帰 → 目的の収束判定 → 目的の暫定承認 → 価値検証。

これは決まった一方向のウィザードではありません。探索は往復可能なグラフ構造を持ちます。

## まず確認してほしいもの

| 種類 | パス | 説明 |
|---|---|---|
| **HTMLデモ** | [`prototype/index.html`](prototype/index.html) | 初回入力から価値検証まで操作できる最重要成果物。ブラウザで開く |
| **一枚絵** | [`visuals/10_journey_overview.png`](visuals/10_journey_overview.png) | 体験・AI／人間の責務・収束までの俯瞰図 |
| **ストーリーボード** | [`visuals/11_storyboard.png`](visuals/11_storyboard.png) | 9つの状態を通したUIの画面遷移 |
| **初回入力モック** | [`visuals/01_start.png`](visuals/01_start.png) | ユーザーが最初にアイデアを入力する画面 |
| 初期目的仮説UI | [`visuals/02_hypothesis.png`](visuals/02_hypothesis.png) | AIの解釈と未確定性 |
| 探索候補UI | [`visuals/03_options.png`](visuals/03_options.png) | 3件の候補を縮小プレビューで比較 |
| 詳細プレビューUI | [`visuals/04_preview.png`](visuals/04_preview.png) | 成果物を見て承認範囲を理解 |
| 探索ステップUI | [`visuals/05_step.png`](visuals/05_step.png) | 成果物と違和感の入力 |
| 探索結果UI | [`visuals/06_findings.png`](visuals/06_findings.png) | 成果物と知見を区別し、目的仮説の変更を提案 |
| 探索履歴UI | [`visuals/07_history.png`](visuals/07_history.png) | 未選択候補に戻る |
| 収束判定UI | [`visuals/08_convergence.png`](visuals/08_convergence.png) | 5観点、根拠と不足を確認 |
| 価値検証への引き継ぎUI | [`visuals/09_validation.png`](visuals/09_validation.png) | 暫定目的と検証計画の受け渡し |
| **ワイヤーフレーム** | [`visuals/wireframe_start.png`](visuals/wireframe_start.png) / [`visuals/wireframe_options.png`](visuals/wireframe_options.png) | 低忠実度の初回画面・候補比較 |
| 編集可能な概念図 | [`visuals/10_journey_overview.html`](visuals/10_journey_overview.html) | 一枚絵のHTML原本 |

画像は**同じHTMLプロトタイプから画面状態を再現して撮影**したものです。旧版の画像を使い回していません。

## 文書

- `docs/00_READ_FIRST.md` — 更新点・導線・限界
- `docs/01_VISION_AND_PRINCIPLES.md` — ビジョンとUX原則
- `docs/02_END_TO_END_JOURNEY.md` — 利用者シナリオ、AI・人間の責務、遷移
- `docs/03_UBIQUITOUS_LANGUAGE.md` — 用語集v0.3（DDD × META）
- `docs/04_DOMAIN_MODEL.md` — Domain Model / BC / 不変条件 / Mermaid
- `docs/05_INFORMATION_ARCHITECTURE_AND_UI.md` — 画面責務とUXコピー
- `docs/06_CONVERGENCE_DESIGN.md` — 目的の収束判定5観点
- `docs/07_AGENT_KNOWLEDGE_ARCHITECTURE.md` — PdM Agent / Advisors / Semantic Knowledge
- `docs/08_IMPLEMENTATION_HANDOFF.md` — Claude Code / Codex実装スライス
- `docs/09_POC_ACCEPTANCE_AND_TEST_PLAN.md` — AC-01〜18、テスト
- `docs/10_DDD_META_DECISIONS.md` — 概念レビュー・残課題
- `docs/11_CHANGELOG.md` — v0.7からの変更理由

`schemas/` には参考JSON Schemaを4件、`examples/` に架空データ例を2件収録しました。スキーマやAPIは**検討用**で、確定した公開仕様ではありません。

## HTMLの操作方法

`prototype/index.html` をChrome/Edge等で開きます。左の「探索を始める」から入力、続いて「探索候補を見る」→「成果物プレビューを開く」→「この探索を承認する」と進めます。候補A/B/Cを選択し直せます。成果物評価後は違和感を入力して探索結果を整理し、別候補へ戻り、収束判定から価値検証への移行まで試せます。

**重要：静的な操作デモ**です。AI推論、入力内容に対応した生成、資料解析、実データの根拠評価、永続化には未接続です。任意の資料選択はファイル名の表示のみ。収束条件の「操作例」は手動シミュレーションで、実際のAIが判定したものではありません。ブラウザの再読み込みでデモ操作履歴はリセットされます。

## 履歴・出典

`history/Blueprint_v0.7_original.zip` は、旧設計の参照資料として保存。旧v0.7の途中画面を最新仕様として扱わないでください。DDD/META Advisorの参照は過去のユーザー提供 `連携用 (2).zip` と旧版レビューを踏襲。個別Advisor実行・評価の実績を本モックが示すものではありません。

## 再現テスト

`python tests/test_prototype_e2e.py`（Python、Playwright、Chromiumが必要）。ブラウザにHTMLを直接投入し、初回入力→承認→結果→別候補→収束→価値検証の一連の操作を確認します。API/AI品質の試験ではありません。
