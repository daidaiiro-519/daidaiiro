# Examples

`contract.example.json` は独自Semantic Contractの**仮の表現**です。規格・正式メタモデルではありません。`sensor.schema.json` は標準JSON Schema形式で書いたデータ契約です。`ui.example.json` は独自UI Contractの概念例であり、現在のどのRendererでもそのまま動く保証はありません。
